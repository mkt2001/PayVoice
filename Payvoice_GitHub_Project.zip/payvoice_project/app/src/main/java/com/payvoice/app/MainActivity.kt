package com.payvoice.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.EditText
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var messageInput: EditText
    private lateinit var speedSeek: SeekBar
    private lateinit var speedLabel: TextView
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tts = TextToSpeech(this, this)
        val prefs = getSharedPreferences("payvoice", MODE_PRIVATE)
        messageInput = findViewById(R.id.messageInput)
        speedSeek = findViewById(R.id.speedSeek)
        speedLabel = findViewById(R.id.speedLabel)
        messageInput.setText(prefs.getString("message", "{app} पर {amount} प्राप्त हुए। धन्यवाद!"))
        speedSeek.progress = prefs.getInt("speed", 3)
        updateSpeedLabel()
        speedSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) = updateSpeedLabel()
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        findViewById<Button>(R.id.saveButton).setOnClickListener {
            prefs.edit().putString("message", messageInput.text.toString().ifBlank { "{app} पर {amount} प्राप्त हुए। धन्यवाद!" })
                .putInt("speed", speedSeek.progress).apply()
            Toast.makeText(this, "सेटिंग सेव हो गई", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.testButton).setOnClickListener {
            if (ttsReady) speak(messageInput.text.toString().replace("{app}", "Google Pay").replace("{amount}", "बीस रुपये"))
            else Toast.makeText(this, "आवाज़ इंजन तैयार हो रहा है", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.accessButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
    }

    private fun updateSpeedLabel() {
        val rate = 0.5f + (speedSeek.progress * 0.1f)
        speedLabel.text = "${if (rate <= 0.8f) "धीमी" else if (rate < 1.0f) "सामान्य से धीमी" else "तेज़"} (${String.format(Locale.US, "%.1f", rate)}x)"
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            val result = tts.setLanguage(Locale("hi", "IN"))
            tts.setSpeechRate(0.75f)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Toast.makeText(this, "फोन में हिंदी TTS voice डाउनलोड करें", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun speak(text: String) {
        val rate = 0.5f + (speedSeek.progress * 0.1f)
        tts.setSpeechRate(rate)
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "payvoice-test")
    }

    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
