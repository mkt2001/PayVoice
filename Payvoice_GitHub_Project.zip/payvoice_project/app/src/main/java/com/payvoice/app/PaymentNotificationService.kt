package com.payvoice.app

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.tts.TextToSpeech
import android.os.Handler
import android.os.Looper
import java.util.Locale
import java.util.regex.Pattern

class PaymentNotificationService : NotificationListenerService() {
    private var tts: TextToSpeech? = null
    private var ready = false
    private val mainHandler = Handler(Looper.getMainLooper())
    private var lastAnnouncement = ""
    private var lastAt = 0L

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val engine = tts ?: return@TextToSpeech
                engine.setLanguage(Locale("hi", "IN"))
                engine.setSpeechRate(0.75f)
                ready = true
            }
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val packageName = sbn.packageName ?: return
        val allowedPackages = setOf(
            "net.one97.paytm", "com.google.android.apps.nbu.paisa.user",
            "com.phonepe.app", "in.org.npci.upiapp"
        )
        if (packageName !in allowedPackages) return
        val extras = sbn.notification.extras ?: return
        val title = extras.getCharSequence("android.title")?.toString().orEmpty()
        val body = extras.getCharSequence("android.text")?.toString().orEmpty()
        val big = extras.getCharSequence("android.bigText")?.toString().orEmpty()
        val content = "$title $body $big".trim()
        if (content.isBlank()) return

        val lower = content.lowercase(Locale.ROOT)
        val hasReceived = listOf("received", "credited", "you got", "payment successful", "पाए", "प्राप्त", "जमा हुए", "जमा")
            .any { lower.contains(it) }
        val hasAmount = Pattern.compile("(?i)(₹|rs\\.?|inr)\\s*[0-9,]+|[0-9,]+\\s*(rupees|रुपये|रुपए)").matcher(content).find()
        if (!hasReceived || !hasAmount) return

        val now = System.currentTimeMillis()
        if (content == lastAnnouncement && now - lastAt < 15_000) return
        lastAnnouncement = content
        lastAt = now

        val amountMatch = Pattern.compile("(?i)(₹|rs\\.?|inr)\\s*([0-9,]+(?:\\.[0-9]{1,2})?)|([0-9,]+(?:\\.[0-9]{1,2})?)\\s*(rupees|रुपये|रुपए)").matcher(content)
        val amount = if (amountMatch.find()) {
            val number = amountMatch.group(2) ?: amountMatch.group(3) ?: ""
            "$number रुपये"
        } else "पेमेंट"
        val appName = when (packageName) {
            "net.one97.paytm" -> "Paytm"
            "com.google.android.apps.nbu.paisa.user" -> "Google Pay"
            "com.phonepe.app" -> "PhonePe"
            else -> "UPI ऐप"
        }
        val prefs = getSharedPreferences("payvoice", MODE_PRIVATE)
        val template = prefs.getString("message", "{app} पर {amount} प्राप्त हुए। धन्यवाद!") ?: "{app} पर {amount} प्राप्त हुए। धन्यवाद!"
        val spoken = template.replace("{app}", appName).replace("{amount}", amount)
        val rate = 0.5f + (prefs.getInt("speed", 3).coerceIn(0, 10) * 0.1f)
        mainHandler.post {
            if (ready) {
                tts?.setLanguage(Locale("hi", "IN"))
                tts?.setSpeechRate(rate)
                tts?.speak(spoken, TextToSpeech.QUEUE_ADD, null, "payment-$now")
            }
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }
}
